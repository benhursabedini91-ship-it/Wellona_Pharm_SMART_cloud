# WPH eFaktura Integration Snapshot

Exported from ChatGPT files on **2025-11-18 04:51**.

## Structure

- `backend/` – Python + Flask app and eFaktura client helpers
- `web/` – Orders web UI HTML
- `docs/` – Official eFaktura PDF guides

Use this folder as the base when you create the private GitHub repo.
